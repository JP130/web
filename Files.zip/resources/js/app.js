require('./bootstrap');
require('alpinejs');
require('./alert');
require('./scripts');
